require('dotenv').config();
const express = require('express');
const fs = require('fs');
const path = require('path');
const app = express();
const PORT = process.env.PORT || 3000;
// API provider tetap KasaPay; branding yang terlihat ke pengunjung adalah ManzPay.
const API_BASE = 'https://api.kasapay.my.id/v1/qris';
const API_KEY = process.env.KASAPAY_API_KEY;
const DATA_FILE = path.join(__dirname, 'orders.json');
const MIN_AMOUNT = 1000;
const MAX_AMOUNT = 100000; // Rp100.000; batas akhir tetap mengikuti aturan provider.
if (!API_KEY) console.warn('PERINGATAN: API pembayaran belum dikonfigurasi di environment server.');
app.use(express.json({ limit: '20kb' }));
app.use(express.static(__dirname));
function load() { try { return JSON.parse(fs.readFileSync(DATA_FILE, 'utf8')); } catch { return {}; } }
function save(data) { fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2)); }
async function paymentApi(endpoint, body) {
  if (!API_KEY) throw new Error('Konfigurasi pembayaran belum dipasang di server.');
  const r = await fetch(`${API_BASE}/${endpoint}`, {
    method: 'POST',
    headers: { Authorization: `Bearer ${API_KEY}`, 'Content-Type': 'application/json' },
    body: JSON.stringify(body)
  });
  const j = await r.json().catch(() => ({ success: false, message: 'Respons server pembayaran tidak valid' }));
  if (!r.ok || !j.success) { const e = new Error(j.message || `Payment HTTP ${r.status}`); e.status = r.status; throw e; }
  return j.data;
}
app.post('/api/qris/generate', async (req, res) => {
  try {
    const amount = Number(req.body.amount);
    if (!Number.isInteger(amount) || amount < MIN_AMOUNT || amount > MAX_AMOUNT)
      return res.status(400).json({ success: false, message: 'Nominal harus Rp1.000 sampai Rp100.000' });
    const orders = load();
    const order_id = String(req.body.order_id || '');
    if (!/^[A-Za-z0-9_-]{1,50}$/.test(order_id))
      return res.status(400).json({ success: false, message: 'order_id tidak valid' });
    const existing = orders[order_id];
    if (existing && existing.status === 'pending' && Date.now() < new Date(existing.expires_at).getTime())
      return res.json({ success: true, data: existing });
    if (existing) return res.status(409).json({ success: false, message: 'Transaksi sebelumnya sudah final. Buat order baru.' });
    const data = await paymentApi('generate', { amount, order_id, metadata: { source: 'manzpay-store' } });
    orders[order_id] = data; save(orders);
    res.json({ success: true, data });
  } catch (e) { res.status(e.status || 500).json({ success: false, message: e.message }); }
});
app.post('/api/qris/status', async (req, res) => {
  try {
    const order_id = String(req.body.order_id || '');
    if (!order_id) return res.status(400).json({ success: false, message: 'order_id wajib diisi' });
    const data = await paymentApi('status', { order_id });
    const orders = load(); orders[order_id] = data; save(orders);
    res.json({ success: true, data });
  } catch (e) { res.status(e.status || 500).json({ success: false, message: e.message }); }
});
app.post('/api/qris/cancel', async (req, res) => {
  try {
    const order_id = String(req.body.order_id || '');
    if (!order_id) return res.status(400).json({ success: false, message: 'order_id wajib diisi' });
    const data = await paymentApi('cancel', { order_id });
    const orders = load(); orders[order_id] = { ...(orders[order_id] || {}), ...data }; save(orders);
    res.json({ success: true, data });
  } catch (e) { res.status(e.status || 500).json({ success: false, message: e.message }); }
});
app.get('/api/health', (req, res) => res.json({ success: true, service: 'ManzPay Backend' }));
app.listen(PORT, () => console.log(`ManzPay aktif di port ${PORT}`));
