KASAPAY STORE — CARA MENJALANKAN

1. Install Node.js versi 18 atau lebih baru.
2. Masuk ke folder project.
3. Jalankan: npm install
4. Salin .env.example menjadi .env
5. Isi KASAPAY_API_KEY dengan API key BARU dari dashboard KasaPay.
   API key yang sempat dikirim di chat sebaiknya di-rotate/revoke.
6. Jalankan: npm start
7. Buka http://localhost:3000

PENGATURAN TOKO
- Klik tombol SETTING di halaman.
- Isi nama toko, nomor DANA, dan nomor WhatsApp.
- Pengaturan tampilan disimpan di browser perangkat yang dipakai.

QRIS
- Tombol QRIS membuka pilihan nominal Rp1.000–Rp10.000.
- Bisa masukkan nominal custom dari Rp1.000 sampai Rp10.000.
- Backend memanggil endpoint KasaPay generate/status/cancel.
- QR dan total tagihan memakai response resmi KasaPay.
- Status diperiksa setiap 5 detik selama halaman pembayaran terbuka.

PENTING
- Jangan upload file .env ke hosting publik atau GitHub.
- Deploy index.html dan server.js bersama-sama sebagai satu aplikasi Node.js.
- HTML saja tidak cukup untuk integrasi aman karena API key wajib disimpan di server.
- Nomor DANA adalah metode transfer manual; QRIS memakai API KasaPay.
- Merchant ID KSP-00025 disimpan sebagai referensi konfigurasi. Dokumentasi API
  yang diberikan tidak menyebut merchant ID sebagai parameter request.
- Untuk produksi, pasang HTTPS dan database persisten. File orders.json adalah
  penyimpanan sederhana untuk instalasi awal.
